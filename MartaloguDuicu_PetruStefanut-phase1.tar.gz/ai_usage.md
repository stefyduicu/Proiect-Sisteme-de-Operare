# AI Usage

Student:Martalogu Duicu Petru Stefanut 
Am folosit ChatGPT sa ma ajute cu doua functii:"parse_condition" si "match_condition". Le-am cerut pentru ca nu stiam exact cum sa sparg sirul "camp:operator:valoare" eficient si voiam sa vad o varianta de la care sa pornesc.

1.Pentru functia parse_condition AI ul mi a dat:

static int parse_condition(const char *input, char *field, char *op, char *value) {
    char tmp[VALUE_LEN];
    strncpy(tmp, input, VALUE_LEN - 1);
    field = strtok(tmp, ":");
    op    = strtok(NULL, ":");
    value = strtok(NULL, ":");
    return (field && op && value) ? 1 : 0;
}


Problema principala era ca folosea "strtok" care scria rezultatele in pointerii locali, nu in buffer-ele mele. Practic functia nu facea nimic util, datele se pierdeau la return. Tot era gresit de fapt. Am rescris-o cu "strchr" ca sa gasesc cele doua caractere ":", calculez lungimile manual si copiez cu "strncpy". Am adaugat si verificarea operatorului care lipsea complet in varianta AI.

2.Pentru functia match_condition AI ul mi a dat:

static int match_condition(Report *r, const char *field,
                            const char *op, const char *value) {
    if (strcmp(field, "severity") == 0) {
        int sev = r->severity;
        int thr = atoi(value);
        if (strcmp(op, "==") == 0) return sev == thr;
        ...
    }
    if (strcmp(field, "timestamp") == 0) {
        return strcmp(r->timestamp, value);
    }
    if (strcmp(field, "category") == 0) {
        return strcmp(r->category, value) == 0;
    }
    return 0;
}

Aici erau mai multe probleme. Cea mai mare era la "timestamp" — AI-ul a facut "strcmp" pe "r->timestamp" care e "time_t", adica un int, nu un string. Nici nu compila. Am corectat sa convertesc valoarea cu "strtol" si sa compar ca "time_t" normal. La "category" trata doar "==" si ignora restul operatorilor, am rescris cu variabila "cmp". Campul "inspector" lipsea de tot, l-am adaugat eu. Am schimbat si "atoi" cu "strtol" si am pus o conditie if pentru "NULL" la inceput.


Restul codului, structurile, permisiunile, operatiile pe fisiere, logging, tot l-am scris eu de la zero.
