Documentatie Utilizare AI - Fazele 1 si 2 

Pe parcursul primelor doua faze, m-am folosit de ChatGPT, Claude si Gemeni ca sa inteleg mai bine anumite functii din C care lucreaza direct cu sistemul de operare si cu fisierele binare, pentru ca nu le stapaneam foarte bine, am folosit pentru a vedea mai multe tipuri de implementari si exemple de folosire a diferitelor functii implementate.De asemenea cand am avut situatii de erori m am ajutat pentru a le 
indeparta.Pot spune ca l am folosit ca un mentor in momentele dificile ))), dar mereu am incercat sa inteleg ce se intampla acolo si sa invat , nu sa il folosesc doar ca un generator de cod.

PENTRU FAZA 1

-Cel mai mult m-am blocat la functia "remove_report". Nu stiam cum sa sterg o structura din mijlocul fisierului "reports.dat" fara sa incarc tot fisierul intr-un vector in memorie. 
-I-am cerut explicatii AI-ului si el m-a invatat cum functioneaza "lseek". Mi-a explicat ca "lseek" muta un fel de "cursor" in interiorul fisierului si mi-a dat ideea de a muta toate inregistrarile cu un pas spre stanga. M-a ajutat sa fac logica cu cele doua offset-uri ("rd" si "wr"): practic mut cursorul de citire cu "lseek(fd, rd, SEEK_SET)", citesc o structura, apoi intorc cursorul cu "lseek(fd, wr, SEEK_SET)" si o suprascriu pe cea veche. La final, tot AI-ul mi-a zis ca trebuie sa folosesc "ftruncate" ca sa tai bucata ramasa la finalul fisierului, altfel ramaneam cu un raport dublat.
-Tot in Faza 1, conform cerintei din enunt, am cerut AI-ului sa imi genereze "parse_cond" si "match_cond". Mi-a generat codul folosind "strchr" pentru a sparge string-ul, dar codul lui compara severitatea si data ca pe niste siruri de caractere (ceea ce strica operatiile de `<` sau `>`). Am intervenit eu pe codul lui si am adaugat conversiile cu "atoi()" si "atol()" in functia de "match_cond".

PENTRU FAZA 2

-In faza a doua, am folosit AI-ul ca sa inteleg cum sa comunic intre programul "city_manager" si "monitor_reports". 
-Eu credeam initial ca functia `kill()` face exact ce spune numele: omoara un proces. AI-ul mi-a explicat cu un exemplu clar ca de fapt "kill(mpid, SIGUSR1)" doar trimite un semnal catre acel PID. 
-De asemenea, m-am folosit de AI cand a trebuit sa implementez stergerea unui intreg director pentru comanda "remove_district". Mi-a explicat ordinea exacta a functiilor: cum sa folosesc "fork()" pentru a crea un copil, in acel copil sa dau "execlp("rm", "rm", "-rf", ...)" pentru a sterge fizic folderul, in timp ce parintele asteapta cuminte cu "waitpid()" ca stergerea sa se termine ca sa nu imi ramana procese zombie prin sistem.
-La semnale, m-am uitat pe exemple de la AI ca sa setez corect "sigaction" cu masca golita "sigemptyset(&sa.sa_mask)" in loc sa folosesc functia mai veche "signal()", exact cum cerea si enuntul proiectului.
