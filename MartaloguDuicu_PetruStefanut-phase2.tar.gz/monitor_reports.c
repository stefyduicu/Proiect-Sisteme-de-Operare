#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#define PID_FILE ".monitor_pid"
int keep_running = 1;
void handle_signal(int sig) {
    if(sig==SIGINT) {
        printf("\nStergem pid-ul si ne oprim.\n");
        keep_running = 0;
    }
    else
      if(sig==SIGUSR1) {
        printf("\nS-a adaugat un raport nou in sistem!\n");
    }
}
int main() {
    pid_t pid=getpid();
    int fd=open(PID_FILE,O_WRONLY | O_CREAT | O_TRUNC,0644);
    if(fd<0) {
        perror("Eroare la crearea fisierului pid");
        return 1;
    }
    char buf[32];
    sprintf(buf,"%d\n",pid);
    write(fd,buf,strlen(buf));
    close(fd);
    printf("monitor_reports pornit.PID=%d salvat in %s\n",pid,PID_FILE);
    printf("Astept semnale...\n"); //SIGUSR1 pt notificare, SIGINT pt oprire
    struct sigaction sa;
    sa.sa_handler=handle_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags=0;
    sigaction(SIGUSR1,&sa,NULL);
    sigaction(SIGINT,&sa,NULL);
    while(keep_running) {
        pause();
    }
    unlink(PID_FILE);
    printf("Fisierul PID a fost sters.\n");
    return 0;
}
