#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#define NAME_LEN 64
#define CAT_LEN 32
#define DESC_LEN 256
#define DIST_LEN 64
#define FIELD_LEN 32
#define OP_LEN 4
#define VAL_LEN 128
#define LOG_LEN 512
#define PERM_DIR 0750
#define PERM_REPORTS 0664
#define PERM_CFG 0640
#define PERM_LOG 0644
#define ROLE_INSP "inspector"
#define ROLE_MGR "manager"
#define FILE_REPORTS "reports.dat"
#define FILE_CFG "district.cfg"
#define FILE_LOG "logged_district"
#define FILE_PID ".monitor_pid"
typedef struct {
    int id;
    char inspector[NAME_LEN];
    double lat;
    double lon;
    char category[CAT_LEN];
    int severity;
    time_t ts;
    char description[DESC_LEN];
} Report;
typedef struct {
    char role[NAME_LEN];
    char user[NAME_LEN];
    char cmd[NAME_LEN];
    char district[DIST_LEN];
    int report_id;
    int threshold;
    char conds[8][VAL_LEN];
    int nconds;
} Args;

static void usage(const char *prog) {
    printf("Mod de utilizare:\n");
    printf("  %s --role <manager|inspector> --user <nume> --add <cartier>\n",prog);
    printf("  %s --role <manager|inspector> --user <nume> --list <cartier>\n",prog);
    printf("  %s --role <manager|inspector> --user <nume> --view <cartier> <id>\n",prog);
    printf("  %s --role manager --user <nume> --remove_report <cartier> <id>\n",prog);
    printf("  %s --role manager --user <nume> --update_threshold <cartier> <val>\n",prog);
    printf("  %s --role <manager|inspector> --user <nume> --filter <cartier> <cond>...\n",prog);
    printf("  %s --role manager --user <nume> --remove_district <cartier>\n",prog);
    exit(1);
}

static void parse_args(int argc, char *argv[], Args *a) {
    memset(a, 0, sizeof(Args));
    if(argc < 2)
      usage(argv[0]);
    for (int i = 1; i < argc; i++)
      {
        if(!strcmp(argv[i],"--role") && i+1<argc)
	  {
            strncpy(a->role,argv[++i],NAME_LEN-1);
          }
	else
	  if(!strcmp(argv[i],"--user") && i+1<argc)
	    {
            strncpy(a->user,argv[++i],NAME_LEN-1);
            }
	else
	  if(!strcmp(argv[i],"--add") && i+1<argc)
	    {
            strcpy(a->cmd,"add");
            strncpy(a->district,argv[++i],DIST_LEN-1);
            }
        else
	  if(!strcmp(argv[i],"--list") && i+1<argc)
	    {
            strcpy(a->cmd,"list");
            strncpy(a->district,argv[++i],DIST_LEN-1);
            }
	else
	  if (!strcmp(argv[i],"--view") && i+2<argc)
	    {
            strcpy(a->cmd,"view");
            strncpy(a->district,argv[++i],DIST_LEN-1);
            a->report_id=atoi(argv[++i]);
            }
	else
	  if(!strcmp(argv[i],"--remove_report") && i+2<argc)
	    {
            strcpy(a->cmd,"remove_report");
            strncpy(a->district, argv[++i],DIST_LEN-1);
            a->report_id=atoi(argv[++i]);
            }
	else
	  if(!strcmp(argv[i],"--update_threshold") && i+2<argc)
	    {
            strcpy(a->cmd,"update_threshold");
            strncpy(a->district,argv[++i],DIST_LEN-1);
            a->threshold=atoi(argv[++i]);
            }
	else
	  if(!strcmp(argv[i],"--filter") && i+1<argc)
	  {
            strcpy(a->cmd,"filter");
            strncpy(a->district,argv[++i],DIST_LEN-1);
            while (i+1<argc && argv[i+1][0]!= '-') {
                if(a->nconds< 8) 
                    strncpy(a->conds[a->nconds++],argv[++i],VAL_LEN-1);
		else 
                    i++;
            }
         }
       else
	  if(!strcmp(argv[i], "--remove_district") && i+1<argc)
	    {
            strcpy(a->cmd, "remove_district");
            strncpy(a->district, argv[++i], DIST_LEN-1);
            }
    }

    if(!a->role[0])
      {
	printf("Lipsa --role.\n");
	exit(1);
      }
    if(strcmp(a->role,ROLE_INSP) && strcmp(a->role,ROLE_MGR))
      {
        printf("Rol necunoscut: %s\n", a->role);
	exit(1);
    }
    if(!a->user[0])
      {
	printf("Lipsa --user.\n");
	exit(1);
      }
    if(!a->cmd[0])
      {
	printf("Nicio comanda specificata.\n");
	exit(1);
      }
}
static char *mode_str(mode_t m,char *buf) {
    buf[0] = (m & S_IRUSR) ? 'r' : '-';
    buf[1] = (m & S_IWUSR) ? 'w' : '-';
    buf[2] = (m & S_IXUSR) ? 'x' : '-';
    buf[3] = (m & S_IRGRP) ? 'r' : '-';
    buf[4] = (m & S_IWGRP) ? 'w' : '-';
    buf[5] = (m & S_IXGRP) ? 'x' : '-';
    buf[6] = (m & S_IROTH) ? 'r' : '-';
    buf[7] = (m & S_IWOTH) ? 'w' : '-';
    buf[8] = (m & S_IXOTH) ? 'x' : '-';
    buf[9] = '\0';
    return buf;
}

static void set_perms(const char *path,mode_t m)
{
    if(chmod(path,m)<0)
      perror("chmod esuat");
}

static void check_perm(const char *path,mode_t bit,const char *role)
{
    struct stat st;
    if(stat(path,&st)<0)
      {
        printf("Eroare stat pe %s\n",path);
        exit(1);
    }
    mode_t check=bit;
    if(!strcmp(role,ROLE_INSP))
      {
        if(bit==S_IRUSR)
	  check=S_IRGRP;
        else
	  if(bit==S_IWUSR)
	    check=S_IWGRP;
	else
	  if(bit==S_IXUSR)
	    check=S_IXGRP;
    }
    if(!(st.st_mode&check))
      {
        printf("Acces refuzat pt rolul %s pe %s\n",role,path);
        exit(1);
    }
}

static void log_action(const char *dist,const char *role,const char *user,const char *action)
{
    if(!strcmp(role,ROLE_INSP))
      return;
    char lpath[512];
    sprintf(lpath, "%s/%s",dist,FILE_LOG);
    struct stat st;
    if(stat(lpath,&st)==0 && !(st.st_mode & S_IWUSR))
      return;
    int fd=open(lpath,O_WRONLY|O_CREAT|O_APPEND,PERM_LOG);
    if(fd < 0)
      return;
    time_t now=time(NULL);
    char ts[64];
    strftime(ts,sizeof(ts),"%Y-%m-%d %H:%M:%S",localtime(&now));
    char line[LOG_LEN];
    int n = sprintf(line,"[%s] role=%s user=%s action=%s\n",ts,role,user,action);
    write(fd,line,n);
    close(fd);
    set_perms(lpath,PERM_LOG);
}

static void make_symlink(const char *dist)
{
    char link[512],target[512];
    sprintf(link,"active_reports-%s",dist);
    sprintf(target,"%s/%s", dist,FILE_REPORTS);
    struct stat lst;
    if(lstat(link, &lst)==0)
      {
        if(!S_ISLNK(lst.st_mode))
	  return;
        unlink(link);
    }
    if(symlink(target,link) < 0)
      perror("symlink esuat");
}

static void ensure_district(const char *dist)
{
    struct stat st;
    if(stat(dist,&st)<0)
      {
        if(mkdir(dist,PERM_DIR) < 0)
	  {
            perror("mkdir esuat");
            exit(1);
        }
    }
    set_perms(dist, PERM_DIR);
    char p[512];
    sprintf(p,"%s/%s",dist,FILE_REPORTS);
    if(stat(p,&st) < 0)
      {
        int fd=open(p,O_WRONLY|O_CREAT,PERM_REPORTS);
        if(fd>=0)
	  close(fd);
    }
    set_perms(p, PERM_REPORTS);
    sprintf(p,"%s/%s",dist,FILE_CFG);
    if(stat(p, &st)<0) {
        int fd=open(p,O_WRONLY | O_CREAT,PERM_CFG);
        if(fd>=0)
	  {
            char *def="severity_threshold=1\n";
            write(fd,def,strlen(def));
            close(fd);
        }
    }
    set_perms(p, PERM_CFG);
    sprintf(p,"%s/%s",dist,FILE_LOG);
    if(stat(p, &st)<0)
      {
        int fd=open(p,O_WRONLY | O_CREAT,PERM_LOG);
        if(fd>=0)
	  close(fd);
    }
    set_perms(p,PERM_LOG);
    make_symlink(dist);
}

static void print_report(const Report *r) {
    char ts[64];
    strftime(ts,sizeof(ts),"%Y-%m-%d %H:%M:%S",localtime(&r->ts));
    printf("ID: %d\n",r->id);
    printf("Inspector: %s\n",r->inspector);
    printf("GPS: %.6f, %.6f\n",r->lat,r->lon);
    printf("Categorie: %s\n",r->category);
    printf("Gravitate: %d\n",r->severity);
    printf("Data: %s\n",ts);
    printf("Descriere: %s\n",r->description);
    printf("---\n");
}

static void notify_monitor(const char *dist,const char *role,const char *user,int rid) {
    int fd = open(FILE_PID,O_RDONLY);
    if(fd<0)
      {
        printf("(monitorul nu ruleaza)\n");
        char msg[128];
        sprintf(msg,"notify_skip report_id=%d no_pid_file",rid);
        log_action(dist,role,user,msg);
        return;
    }
    char buf[32];
    int n=read(fd,buf,sizeof(buf)-1);
    close(fd);    
    if(n<=0)
      return;
    buf[n]='\0';
    int mpid=atoi(buf);
    if(mpid>0) {
        if(kill(mpid, SIGUSR1) < 0)
	  {
            printf("Eroare trimitere semnal la %d\n",mpid);
            char msg[128];
            sprintf(msg,"notify_fail report_id=%d pid=%d",rid,mpid);
            log_action(dist,role,user,msg);
        }
	else
	  {
	  printf("Monitor notificat (PID %d)\n",mpid);
            char msg[128];
            sprintf(msg,"notify_ok report_id=%d pid=%d",rid, mpid);
            log_action(dist, role, user, msg);
        }
    }
}

static void cmd_add(const Args *a)
{
    ensure_district(a->district);
    char rpath[512];
    sprintf(rpath,"%s/%s",a->district,FILE_REPORTS);
    check_perm(rpath, S_IWUSR, a->role);
    int fd=open(rpath, O_RDWR | O_CREAT,PERM_REPORTS);
    if (fd<0)
      {
        perror("Eroare deschidere fisier rapoarte");
        exit(1);
    }
    int max_id=0;
    Report tmp;
    while (read(fd,&tmp,sizeof(Report))==sizeof(Report))
      {
        if (tmp.id>max_id)
	  max_id=tmp.id;
    }
    Report r;
    memset(&r, 0, sizeof(Report));
    r.id=max_id+1;
    r.ts=time(NULL);
    strcpy(r.inspector,a->user);
    printf("Latitudine: ");
    scanf("%lf",&r.lat);
    printf("Longitudine: ");
    scanf("%lf",&r.lon);
    printf("Categorie: ");
    scanf("%31s",r.category);
    printf("Gravitate (1/2/3): ");
    scanf("%d",&r.severity);
    if (r.severity<1 || r.severity>3)
      r.severity=1;
    int c;
    while ((c = getchar())!='\n' && c!=EOF);
    printf("Descriere: ");
    fgets(r.description, DESC_LEN, stdin);
    int len=strlen(r.description);
    if (len>0 && r.description[len-1]=='\n')
      r.description[len-1] = '\0';
    lseek(fd, 0, SEEK_END);
    write(fd,&r,sizeof(Report));
    close(fd);
    set_perms(rpath,PERM_REPORTS);
    printf("Raport #%d salvat.\n",r.id);
    char action[128];
    sprintf(action,"add report_id=%d",r.id);
    log_action(a->district,a->role,a->user,action);
    notify_monitor(a->district,a->role,a->user,r.id);
}

static void cmd_list(const Args *a)
{
    char rpath[512];
    sprintf(rpath,"%s/%s",a->district,FILE_REPORTS);
    struct stat st;
    if(stat(rpath,&st)<0)
      {
        printf("Cartierul nu are rapoarte.\n");
        exit(1);
    }
    check_perm(rpath,S_IRUSR,a->role);
    char pbuf[10],mbuf[64];
    mode_str(st.st_mode,pbuf);
    strftime(mbuf, sizeof(mbuf),"%Y-%m-%d %H:%M:%S",localtime(&st.st_mtime));
    printf("Fisier: %s\nPermisiuni: %s | Size: %lld | Modificat: %s\n\n",rpath,pbuf,(long long)st.st_size,mbuf);
    int fd=open(rpath,O_RDONLY);
    if(fd<0)
      exit(1);
    Report r;
    int cnt=0;
    while(read(fd,&r,sizeof(Report))==sizeof(Report))
      {
        print_report(&r);
        cnt++;
    }
    close(fd);
    printf("Total: %d rapoarte.\n",cnt);
    log_action(a->district,a->role,a->user,"list");
}

static void cmd_view(const Args *a)
{
    char rpath[512];
    sprintf(rpath,"%s/%s",a->district,FILE_REPORTS);
    check_perm(rpath,S_IRUSR,a->role);
    int fd = open(rpath,O_RDONLY);
    if (fd < 0) exit(1);
    Report r;
    int found = 0;
    while (read(fd,&r,sizeof(Report))==sizeof(Report))
      {
        if (r.id==a->report_id)
	  {
            print_report(&r);
            found = 1;
            break;
        }
    }
    close(fd);
    if (!found)
      printf("Nu am gasit raportul %d\n",a->report_id);
    else
      {
        char act[64];
        sprintf(act,"view report_id=%d",a->report_id);
        log_action(a->district,a->role,a->user,act);
    }
}

static void cmd_remove_report(const Args *a)
{
    if (strcmp(a->role,ROLE_MGR))
      {
        printf("Eroare: Doar managerul poate sterge.\n");
        exit(1);
    }
    char rpath[512];
    sprintf(rpath,"%s/%s",a->district,FILE_REPORTS);
    check_perm(rpath,S_IWUSR,a->role);
    int fd=open(rpath, O_RDWR);
    if(fd<0)
      exit(1);
    off_t tgt=-1;
    Report r;
    while(read(fd,&r,sizeof(Report))==sizeof(Report))
      {
        if (r.id==a->report_id) {
            tgt=lseek(fd,0,SEEK_CUR)-sizeof(Report);
            break;
        }
    }
    if(tgt<0)
      {
        printf("Raportul nu exista.\n");
        close(fd);
        exit(1);
    }
    off_t rd=tgt+sizeof(Report);
    off_t wr=tgt;
    while(1){
        lseek(fd, rd, SEEK_SET);
        if(read(fd,&r,sizeof(Report))!=sizeof(Report))
	  break;
        lseek(fd,wr,SEEK_SET);
        write(fd,&r,sizeof(Report));
        rd=rd+sizeof(Report);
        wr=wr+sizeof(Report);
    }
    struct stat st;
    fstat(fd, &st);
    ftruncate(fd,st.st_size-sizeof(Report));
    close(fd);
    printf("Raportul %d a fost sters.\n",a->report_id);
    char act[64];
    sprintf(act, "remove_report report_id=%d",a->report_id);
    log_action(a->district,a->role,a->user,act);
}

static void cmd_update_threshold(const Args *a) {
    if (strcmp(a->role,ROLE_MGR))
      {
        printf("Doar managerul schimba pragul.\n");
        exit(1);
    }
    char cpath[512];
    sprintf(cpath,"%s/%s",a->district,FILE_CFG);
    struct stat st;
    if(stat(cpath, &st) < 0)
      exit(1);
    if((st.st_mode & 0777)!=PERM_CFG)
      {
        printf("Securitate: config-ul nu are 0640.\n");
        exit(1);
    }
    check_perm(cpath,S_IWUSR,a->role);
    int fd = open(cpath,O_WRONLY | O_TRUNC);
    if (fd < 0) exit(1);
    char buf[64];
    int n = sprintf(buf,"severity_threshold=%d\n",a->threshold);
    write(fd, buf, n);
    close(fd);
    printf("Prag actualizat la %d.\n",a->threshold);
    char act[64];
    sprintf(act,"update_threshold val=%d",a->threshold);
    log_action(a->district, a->role,a->user,act);
}

static void cmd_remove_district(const Args *a)
{
    if(strcmp(a->role,ROLE_MGR)) {
        printf("Manager only.\n");
        exit(1);
    }
    struct stat st;
    if(stat(a->district, &st) < 0 || !S_ISDIR(st.st_mode)) {
        printf("Cartier invalid.\n");
        exit(1);
    }
    char lname[512];
    sprintf(lname,"active_reports-%s",a->district);
    unlink(lname);
    pid_t pid = fork();
    if(pid == 0) {
        execlp("rm","rm","-rf",a->district, NULL);
        exit(1);
    }
    int status;
    waitpid(pid, &status, 0);
    if(WIFEXITED(status) && WEXITSTATUS(status) == 0)
        printf("Cartier %s sters.\n",a->district);
    else 
        printf("Eroare la stergere.\n");
}

static int parse_cond(const char *in,char *field,char *op,char *val)
{
    if (!in || !field || !op || !val)
      return 0;
    const char *p1=strchr(in, ':');
    if (!p1)
      return 0;
    int lf=p1-in;
    strncpy(field,in,lf);
    field[lf] = '\0';
    const char *p2=strchr(p1+1,':');
    if (!p2)
      return 0;
    int lo=p2-(p1+1);
    strncpy(op,p1+1,lo);
    op[lo]='\0';
    strcpy(val,p2+1);
    return 1;
}

static int match_cond(Report *r,const char *field,const char *op,const char *val)
{
    if(!strcmp(field,"severity"))
      {
        int v=r->severity,t=atoi(val);
        if(!strcmp(op,"=="))
	  return v==t;
        if (!strcmp(op,"!="))
	  return v!=t;
        if (!strcmp(op,"<"))
	  return v<t;
        if (!strcmp(op,"<="))
	  return v<=t;
        if (!strcmp(op,">"))
	  return v>t;
        if (!strcmp(op,">="))
	  return v>=t;
    }
    if(!strcmp(field,"timestamp"))
      {
        time_t v=r->ts,t=atol(val);
        if(!strcmp(op,"=="))
	  return v==t;
        if(!strcmp(op,"!="))
	  return v!=t;
        if(!strcmp(op,"<"))
	  return v<t;
        if(!strcmp(op,"<="))
	  return v<=t;
        if(!strcmp(op,">"))
	  return v>t;
        if(!strcmp(op,">="))
	  return v>=t;
    }
    if(!strcmp(field, "category"))
      {
        int c=strcmp(r->category, val);
        if(!strcmp(op,"=="))
	  return c==0;
        if(!strcmp(op,"!="))
	  return c!=0;
    }
    if(!strcmp(field, "inspector"))
      {
        int c = strcmp(r->inspector, val);
        if(!strcmp(op,"=="))
	  return c==0;
        if(!strcmp(op,"!="))
	  return c!=0;
    }
    return 0;
}

static void cmd_filter(const Args *a) {
    char rpath[512];
    sprintf(rpath,"%s/%s",a->district,FILE_REPORTS);
    check_perm(rpath, S_IRUSR, a->role);
    if (a->nconds == 0)
      exit(1);
    int fd=open(rpath,O_RDONLY);
    if (fd < 0)
      exit(1);
    char fields[8][FIELD_LEN],ops[8][OP_LEN],vals[8][VAL_LEN];
    for (int i = 0; i < a->nconds; i++)
      {
        parse_cond(a->conds[i],fields[i],ops[i],vals[i]);
    }
    Report r;
    int found=0;
    while(read(fd,&r,sizeof(Report))==sizeof(Report))
      {
        int ok=1;
        for (int i = 0;i<a->nconds;i++)
	  {
	  if(!match_cond(&r,fields[i],ops[i],vals[i]))
	    { 
                ok = 0;
		break; 
            }
        }
        if(ok)
	  { 
            print_report(&r); 
            found++; 
        }
    }
    close(fd);
    printf("%d rapoarte gasite.\n",found);
    log_action(a->district,a->role,a->user,"filter");
}

int main(int argc,char *argv[]) {
    Args a;
    parse_args(argc, argv, &a);
    if(!strcmp(a.cmd, "add"))
      cmd_add(&a);
    else
      if (!strcmp(a.cmd, "list"))
	cmd_list(&a);
    else
      if (!strcmp(a.cmd, "view"))
	cmd_view(&a);
    else
      if (!strcmp(a.cmd, "remove_report"))
	cmd_remove_report(&a);
    else
      if (!strcmp(a.cmd, "update_threshold"))
	cmd_update_threshold(&a);
    else
      if (!strcmp(a.cmd, "filter"))
	cmd_filter(&a);
    else
      if (!strcmp(a.cmd, "remove_district"))
	cmd_remove_district(&a);
    else
      printf("Comanda necunoscuta.\n");
    return 0;
}
